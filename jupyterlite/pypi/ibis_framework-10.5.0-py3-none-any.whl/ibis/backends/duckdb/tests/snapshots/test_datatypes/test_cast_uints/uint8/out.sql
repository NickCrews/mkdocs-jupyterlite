SELECT
  CAST("t0"."a" AS UTINYINT) AS "Cast(a, uint8)"
FROM "t" AS "t0"