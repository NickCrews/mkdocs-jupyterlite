SELECT
  EXTRACT(year FROM `t0`.`i`) AS `tmp`
FROM `table` AS `t0`