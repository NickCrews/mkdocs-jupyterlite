SELECT
  SUM(`t0`.`a`) AS `Sum(a)`
FROM `table` AS `t0`