SELECT
  *
FROM `functional_alltypes` AS `t0`
UNION ALL
SELECT
  *
FROM `functional_alltypes` AS `t0`