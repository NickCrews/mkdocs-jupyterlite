function f() {
    let a = true;
    let b = false;
    let c = null;
    return ((c !== null) ? a : b);
}