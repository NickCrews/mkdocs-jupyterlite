SELECT
  st_boundingbox(`t0`.`geog`).xmin AS `tmp`
FROM `t` AS `t0`