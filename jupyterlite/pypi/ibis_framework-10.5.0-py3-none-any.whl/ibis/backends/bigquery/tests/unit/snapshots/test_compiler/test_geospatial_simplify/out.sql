SELECT
  st_simplify(`t0`.`geog`, 5.2) AS `tmp`
FROM `t` AS `t0`