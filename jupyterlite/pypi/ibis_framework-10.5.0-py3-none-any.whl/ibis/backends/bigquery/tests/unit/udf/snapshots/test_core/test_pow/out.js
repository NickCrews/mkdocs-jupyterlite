function f() {
    let a = 1;
    return Math.pow(a, 2);
}