SELECT
  st_pointn(`t0`.`geog`, 3) AS `tmp`
FROM `t` AS `t0`