SELECT
  AVG(CAST(`t0`.`bool_col` AS INT64)) AS `Mean_bool_col`
FROM `functional_alltypes` AS `t0`