SELECT
  st_centroid(`t0`.`geog`) AS `tmp`
FROM `t` AS `t0`