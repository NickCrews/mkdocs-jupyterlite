SELECT
  SHA256('test') AS `tmp`