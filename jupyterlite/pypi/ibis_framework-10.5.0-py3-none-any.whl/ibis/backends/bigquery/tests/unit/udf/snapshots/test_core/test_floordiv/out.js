function f() {
    let a = 1;
    return Math.floor(a / 2);
}