SELECT
  EXTRACT(year FROM DATE(2017, 1, 1)) AS `ExtractYear_datetime_date_2017_1_1`