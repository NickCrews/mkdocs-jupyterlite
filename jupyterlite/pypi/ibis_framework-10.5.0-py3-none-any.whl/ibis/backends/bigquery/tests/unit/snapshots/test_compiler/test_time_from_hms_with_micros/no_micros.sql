SELECT
  TIME(12, 34, 56) AS `datetime_time_12_34_56`