SELECT
  st_azimuth(`t0`.`p0`, `t0`.`p1`) AS `tmp`
FROM `t` AS `t0`