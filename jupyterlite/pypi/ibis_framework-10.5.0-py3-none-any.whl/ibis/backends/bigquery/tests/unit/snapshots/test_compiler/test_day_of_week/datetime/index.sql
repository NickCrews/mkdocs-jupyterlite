SELECT
  MOD(EXTRACT(dayofweek FROM DATETIME('2017-01-01T04:55:59')) + 5, 7) AS `DayOfWeekIndex_datetime_datetime_2017_1_1_4_55_59`