SELECT
  EXTRACT(year FROM DATETIME('2017-01-01T04:55:59')) AS `ExtractYear_datetime_datetime_2017_1_1_4_55_59`