SELECT
  ieee_divide(`t0`.`double_col`, 0) AS `Divide_double_col_0`
FROM `functional_alltypes` AS `t0`