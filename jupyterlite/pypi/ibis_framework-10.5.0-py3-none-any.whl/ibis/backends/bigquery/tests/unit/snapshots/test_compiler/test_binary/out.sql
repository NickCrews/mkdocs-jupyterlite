SELECT
  CAST(`t0`.`value` AS BYTES) AS `Cast_value_binary`
FROM `t` AS `t0`