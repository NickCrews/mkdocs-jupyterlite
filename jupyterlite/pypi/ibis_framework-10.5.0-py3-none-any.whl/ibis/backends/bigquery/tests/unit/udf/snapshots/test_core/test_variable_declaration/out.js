function f() {
    let c = 1;
    return (c + 2);
}