SELECT
  'a\\b\\c' AS `'a_b_c'`