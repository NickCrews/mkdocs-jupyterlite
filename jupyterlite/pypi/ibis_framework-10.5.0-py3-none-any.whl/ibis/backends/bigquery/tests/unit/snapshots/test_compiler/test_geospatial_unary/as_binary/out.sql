SELECT
  st_asbinary(`t0`.`geog`) AS `tmp`
FROM `t` AS `t0`