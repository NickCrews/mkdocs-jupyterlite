function f(a) {
    let x = {};
    let y = '2';
    x[y] = y;
    return x;
}