SELECT
  "t0"."int_col" AS "int_col"
FROM "functional_alltypes" AS "t0"