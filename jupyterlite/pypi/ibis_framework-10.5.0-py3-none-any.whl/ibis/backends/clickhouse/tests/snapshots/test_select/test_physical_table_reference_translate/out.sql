SELECT
  *
FROM "functional_alltypes"