SELECT
  position("t0"."string_col", "t0"."string_col") - 1 AS "StringFind(string_col, string_col)"
FROM "functional_alltypes" AS "t0"