SELECT
  "t0"."int_col" + "t0"."tinyint_col" + "t0"."double_col" AS "Add(Add(int_col, tinyint_col), double_col)"
FROM "functional_alltypes" AS "t0"