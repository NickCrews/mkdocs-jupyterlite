SELECT
  "t0"."int_col" < "t0"."tinyint_col" AS "Less(int_col, tinyint_col)"
FROM "functional_alltypes" AS "t0"