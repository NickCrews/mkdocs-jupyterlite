SELECT
  GREATEST("t0"."int_col", 10) AS "Greatest((int_col, 10))"
FROM "functional_alltypes" AS "t0"