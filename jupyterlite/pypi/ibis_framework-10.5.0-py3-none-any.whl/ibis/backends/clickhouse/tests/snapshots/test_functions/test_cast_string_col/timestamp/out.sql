SELECT
  CAST("t0"."string_col" AS Nullable(DateTime)) AS "Cast(string_col, timestamp)"
FROM "functional_alltypes" AS "t0"