SELECT
  "t0"."timestamp_col" AS "timestamp_col"
FROM "functional_alltypes" AS "t0"