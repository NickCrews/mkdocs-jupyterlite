SELECT
  CAST("t0"."double_col" AS Nullable(Int16)) AS "Cast(double_col, int16)"
FROM "functional_alltypes" AS "t0"