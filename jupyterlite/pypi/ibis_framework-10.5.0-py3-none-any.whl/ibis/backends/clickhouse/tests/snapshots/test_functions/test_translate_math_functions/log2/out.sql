SELECT
  LOG2("t0"."double_col") AS "Log2(double_col)"
FROM "functional_alltypes" AS "t0"