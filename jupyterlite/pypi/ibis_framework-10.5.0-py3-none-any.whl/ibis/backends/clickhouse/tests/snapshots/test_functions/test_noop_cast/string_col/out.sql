SELECT
  "t0"."string_col" AS "string_col"
FROM "functional_alltypes" AS "t0"