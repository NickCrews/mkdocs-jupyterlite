SELECT
  LN("t0"."int_col") + "t0"."double_col" AS "Add(Log(int_col), double_col)"
FROM "functional_alltypes" AS "t0"